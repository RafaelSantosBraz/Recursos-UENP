# Recursos-UENP
Aplicação WEB resultado do estudo de caso de Alocação de Recursos da UENP-CLM.

var app = angular.module('MyApp', ['ngMaterial'], ["ngRoute"])
app.run(function () {
    console.log('MyApp is ready!');
});
app.config(function ($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "/app/views/login.html"
        })
});
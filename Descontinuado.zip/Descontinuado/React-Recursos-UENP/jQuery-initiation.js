// início dos recursos Materialize com jQuery
$(document).ready(function () {
    Materialize.updateTextFields();
});
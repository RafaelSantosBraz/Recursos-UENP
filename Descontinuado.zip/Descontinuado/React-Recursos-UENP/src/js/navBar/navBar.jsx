import React from 'react';

class Navbar extends React.Component {

    constructor(props) {
        super(props);
    }
    
    render() {
        return (
            <div>                
                <nav>
                    <div className="nav-wrapper container">
                        <a href="#" className="brand-logo">{this.props.logo}</a>
                        <ul id="nav-mobile" className="right hide-on-med-and-down">
                            <li><a href="#">Configurações</a></li>
                            <li><a href="#">Conta</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        );
    }
}

export default Navbar;
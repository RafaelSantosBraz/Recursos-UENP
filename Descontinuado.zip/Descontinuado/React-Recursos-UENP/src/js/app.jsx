import ReactDOM from 'react-dom';
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Loadable from 'react-loadable';

import NavBar from './navBar/navBar';
//import FooterNew from './footerNew/footerNew';
import Loading from './loading/loading';

let home = () => Loadable(
    {
        loader: () => import('./footerNew/footerNew'),
        loading: Loading
    }
);

// variável local que contém o código a ser substituído no (app ID)
let App = (
    <div>
        <NavBar logo="Recursos UENP" />
    </div>
);

ReactDOM.render(App, document.getElementById("app"));